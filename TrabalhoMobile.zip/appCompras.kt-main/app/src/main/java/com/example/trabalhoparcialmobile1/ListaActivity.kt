package com.example.trabalhoparcialmobile1

import com.example.trabalhoparcialmobile1.ItemAdapter
import com.example.trabalhoparcialmobile1.R
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.appcompat.widget.SearchView
import android.widget.Button
import com.example.trabalhoparcialmobile1.model.Item
import com.example.trabalhoparcialmobile1.model.Lista

class ListaActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var itemAdapter: ItemAdapter
    private lateinit var searchView: SearchView
    private lateinit var lista: Lista

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.lista_de_itens_ususario)

        recyclerView = findViewById(R.id.recyclerViewListaDeCompras)
        recyclerView.layoutManager = LinearLayoutManager(this)

        searchView = findViewById(R.id.searchView)

        lista = Lista("Compras", "")

        itemAdapter = ItemAdapter(lista.Itens)
        recyclerView.adapter = itemAdapter

        val buttonAdicionarItem = findViewById<Button>(R.id.criarButton)
        buttonAdicionarItem.setOnClickListener {
            val intent = Intent(this, AddItemActivity::class.java)
            startActivityForResult(intent, REQUEST_CODE_NOVO_ITEM)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_CODE_NOVO_ITEM && resultCode == RESULT_OK) {
            val nomeItem = data?.getStringExtra("nomeItem") ?: ""
            val quantidadeItem = data?.getStringExtra("quantidadeItem") ?: ""
            val unidadeItem = data?.getStringExtra("unidadeItem") ?: ""
            val categoriaItem = data?.getStringExtra("categoriaItem") ?: ""

            if (nomeItem.isNotEmpty()) {
                val novoItem = Item(nome = nomeItem, quantidade = quantidadeItem, unidade = unidadeItem, categoria = categoriaItem)
                lista.Itens.add(novoItem) 
                itemAdapter.notifyItemInserted(lista.Itens.size - 1)
            }
        }
    }

    companion object {
        const val REQUEST_CODE_NOVO_ITEM = 1
    }
}

