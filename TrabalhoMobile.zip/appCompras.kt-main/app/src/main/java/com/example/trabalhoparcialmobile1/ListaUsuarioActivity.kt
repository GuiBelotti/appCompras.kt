package com.example.trabalhoparcialmobile1

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.SavedStateViewModelFactory
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.trabalhoparcialmobile1.databinding.ListasUsuarioBinding
import com.example.trabalhoparcialmobile1.model.CriarListaActivity
import com.example.trabalhoparcialmobile1.model.Lista

class ListaUsuarioActivity : AppCompatActivity() {

    private val REQUEST_CODE_CRIAR_LISTA = 1
    private lateinit var adapter: ListaAdapter
    private lateinit var listaViewModel: ListaViewModel
    private lateinit var binding: ListasUsuarioBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ListasUsuarioBinding.inflate(layoutInflater)
        setContentView(binding.root)

        listaViewModel = ViewModelProvider(this, SavedStateViewModelFactory(application, this))
            .get(ListaViewModel::class.java)

        binding.recyclerViewListaDeCompras.layoutManager = LinearLayoutManager(this)

        adapter = ListaAdapter(listaViewModel.getListas())
        binding.recyclerViewListaDeCompras.adapter = adapter

        binding.criarButton.setOnClickListener {
            val intent = Intent(this, CriarListaActivity::class.java)
            startActivityForResult(intent, REQUEST_CODE_CRIAR_LISTA)
        }

        binding.voltarButton.setOnClickListener {
            listaViewModel.limparListas()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        binding.SearchViewpesquisa.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                adapter.filtrar(newText ?: "")
                return true
            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_CRIAR_LISTA && resultCode == Activity.RESULT_OK && data != null) {
            val nomeLista = data.getStringExtra("nomeLista")
            val imageUriString = data.getStringExtra("imageUri")

            if (nomeLista != null && imageUriString != null) {
                val novaLista = Lista(nomeLista, imageUriString)
                listaViewModel.adicionarLista(novaLista)
                adapter.notifyDataSetChanged()
            }
        }
    }
}