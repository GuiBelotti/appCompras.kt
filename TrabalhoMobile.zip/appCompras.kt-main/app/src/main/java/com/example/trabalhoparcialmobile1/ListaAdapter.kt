package com.example.trabalhoparcialmobile1

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.trabalhoparcialmobile1.model.Lista

class ListaAdapter(private var listas: List<Lista>) : RecyclerView.Adapter<ListaAdapter.ListaViewHolder>() {

    private var listasFiltradas: List<Lista> = listas // Armazena a lista filtrada

    // ViewHolder para cada item da lista
    class ListaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nomeLista: TextView = itemView.findViewById(R.id.textViewNomeLista)
       val fotoLista: ImageView = itemView.findViewById(R.id.imageViewLista)
    }

    // Converte xml em hierarquia de views
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListaViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_lista, parent, false)
        return ListaViewHolder(view)
    }

    // Vincula os dados da lista ao ViewHolder
    override fun onBindViewHolder(holder: ListaViewHolder, position: Int) {
        val lista = listasFiltradas[position]
        holder.nomeLista.text = lista.nome

        // Carregar a imagem
        if (lista.foto.isNullOrEmpty()) {
            holder.fotoLista.setImageResource(R.drawable.ic_launcher_background) // Imagem padrão
        } else {
            val imageUri = Uri.parse(lista.foto)
            Glide.with(holder.itemView.context)
                .load(imageUri)
                .placeholder(R.drawable.ic_launcher_background) // Imagem padrão
                .into(holder.fotoLista)
        }
    }

    // Retorna o número de itens na lista filtrada
    override fun getItemCount(): Int {
        return listasFiltradas.size
    }

    // Método para filtrar as listas com base na pesquisa
    fun filtrar(query: String) {
        listasFiltradas = if (query.isEmpty()) {
            listas // Retorna a lista completa se a consulta estiver vazia
        } else {
            listas.filter { it.nome.contains(query, ignoreCase = true) } // Filtra as listas
        }
        notifyDataSetChanged() // Notifica a mudança na lista
    }
}
