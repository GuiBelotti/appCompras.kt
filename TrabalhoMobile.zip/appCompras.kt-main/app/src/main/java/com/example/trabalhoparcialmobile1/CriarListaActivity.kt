package com.example.trabalhoparcialmobile1.model

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.trabalhoparcialmobile1.R

class CriarListaActivity : AppCompatActivity() {

    private var imageUri: Uri? = null
    private lateinit var pickImageLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.criar_lista)

        val buttonAdicionarImagem = findViewById<Button>(R.id.buttonAdicionarImagem)
        val buttonCriarLista = findViewById<Button>(R.id.buttonCriarLista)
        val editTextNomeLista = findViewById<EditText>(R.id.editTextNomeLista)
        val imageViewPreview = findViewById<ImageView>(R.id.imageViewPreview)


        pickImageLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                imageUri = result.data?.data
                imageViewPreview.setImageURI(imageUri)
            }
        }

        // abre a galeria
        buttonAdicionarImagem.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK)
            intent.type = "image/*"
            pickImageLauncher.launch(intent)
        }

        buttonCriarLista.setOnClickListener {
            val nomeLista = editTextNomeLista.text.toString()

            // erro se o nome da lista for vazio
            if (nomeLista.isEmpty()) {
                return@setOnClickListener
            }

            // retornar dados da lista para a activity de listas do usuário
            val resultIntent = Intent()

            // nome
            resultIntent.putExtra("nomeLista", nomeLista)

            if (imageUri == null) {
                // Se o usuário não selecionar uma imagem
                val defaultImageUri = Uri.parse("android.resource://" + packageName + "/" + R.drawable.imagemlista)
                resultIntent.putExtra("imageUri", defaultImageUri.toString())
            } else {
                // o usuário selecionar uma imagem
                resultIntent.putExtra("imageUri", imageUri.toString())
            }

            setResult(Activity.RESULT_OK, resultIntent)
            finish()
        }
    }
}
